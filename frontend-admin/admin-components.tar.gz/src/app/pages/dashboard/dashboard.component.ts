import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { DataService } from '../../services/data.service';
import { Order, badgeClass } from '../../models';
import { MOCK_KPIS } from '../../mock';

@Component({
  selector: 'sf-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit {
  private data = inject(DataService);

  kpis = signal<typeof MOCK_KPIS>([]);
  orders = signal<Order[]>([]);

  /** Five most recent orders, newest first. */
  recentOrders = computed(() => this.orders().slice(-5).reverse());

  /** Orders needing attention (Pending) — surfaced on the dashboard. */
  pendingCount = computed(() => this.orders().filter(o => o.status === 'Pending').length);

  badgeClass = badgeClass;

  ngOnInit(): void {
    this.data.getKpis().subscribe(k => this.kpis.set(k));
    this.data.getOrders().subscribe(o => this.orders.set(o));
  }
}
