import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { OrderStatus, STATUS_FLOW, TrackedOrder, badgeClass } from '../../models';

@Component({
  selector: 'sf-track',
  imports: [FormsModule],
  template: `
    <div class="max-w-[760px] mx-auto px-7 py-8 pb-16">
      <div class="text-[12.5px] text-warmmuted mb-2">Home / <b class="text-warmink">Track Order</b></div>
      <h1 class="font-display text-[28px] font-bold mb-1">Your Orders</h1>
      <p class="text-warmmuted text-sm mb-4">Follow every order from placed to delivered.</p>

      <input placeholder="Search by order number, e.g. AL-3081"
        [ngModel]="search()" (ngModelChange)="search.set($event)"
        class="w-full border border-warmborder rounded-[9px] px-3.5 py-2.5 text-[13.8px] bg-paper outline-none focus:border-flame focus:bg-white mb-4">

      @for (o of filtered(); track o.id) {
        <div class="border border-warmborder rounded-2xl p-5 mb-4 bg-white">
          <div class="flex justify-between items-center">
            <b>{{ o.id }}</b>
            <span [class]="'badge ' + badgeClass(o.status)">{{ o.status }}</span>
          </div>
          <div class="text-[12.5px] text-warmmuted mt-1.5 mb-4">{{ o.date }} · {{ o.items }} items · \${{ o.total }}</div>
          <div class="flex justify-between relative">
            <div class="absolute top-2.5 left-[5%] right-[5%] h-0.5 bg-warmborder"></div>
            @for (s of flow; track s; let i = $index) {
              <div class="flex flex-col items-center gap-1.5 flex-1 relative z-10">
                <span class="w-5 h-5 rounded-full"
                  [class]="i < stepIndex(o) ? 'bg-success' : i === stepIndex(o) ? 'bg-flame' : 'bg-warmborder'"></span>
                <span class="text-[10px] text-center max-w-[66px]"
                  [class]="i <= stepIndex(o) ? 'text-warmink font-semibold' : 'text-warmmuted'">{{ s }}</span>
              </div>
            }
          </div>
        </div>
      } @empty {
        <p class="text-warmmuted">No orders found for "{{ search() }}".</p>
      }
    </div>
  `,
})
export class TrackComponent implements OnInit {
  private data = inject(DataService);

  orders = signal<TrackedOrder[]>([]);
  search = signal('');

  flow = STATUS_FLOW;
  badgeClass = badgeClass;

  filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    return q ? this.orders().filter(o => o.id.toLowerCase().includes(q)) : this.orders();
  });

  stepIndex(o: TrackedOrder): number {
    return STATUS_FLOW.indexOf(o.status as OrderStatus);
  }

  ngOnInit(): void {
    this.data.getOrders().subscribe(o => this.orders.set(o));
  }
}
