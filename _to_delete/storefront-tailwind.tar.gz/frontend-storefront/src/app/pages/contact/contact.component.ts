import { Component, computed, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'sf-contact',
  imports: [FormsModule],
  template: `
    <div class="max-w-[560px] mx-auto px-7 py-8 pb-16">
      <div class="text-[12.5px] text-warmmuted mb-2">Home / <b class="text-warmink">Contact</b></div>
      <h1 class="font-display text-[28px] font-bold mb-1">We're here to help</h1>
      <p class="text-warmmuted text-sm mb-5">Questions about an order or a product? Reach out below.</p>

      @if (sent()) {
        <p class="text-success font-semibold">✓ Message sent — we'll reply within one business day.</p>
      } @else {
        <div class="flex flex-col gap-3">
          <input class="border border-warmborder rounded-[9px] px-3.5 py-2.5 text-[13.8px] bg-paper outline-none focus:border-flame focus:bg-white"
            placeholder="Full Name" [ngModel]="name()" (ngModelChange)="name.set($event)">
          <div class="grid grid-cols-2 gap-3">
            <input class="border border-warmborder rounded-[9px] px-3.5 py-2.5 text-[13.8px] bg-paper outline-none focus:border-flame focus:bg-white"
              placeholder="Email" [ngModel]="email()" (ngModelChange)="email.set($event)">
            <input class="border border-warmborder rounded-[9px] px-3.5 py-2.5 text-[13.8px] bg-paper outline-none focus:border-flame focus:bg-white"
              placeholder="Order Number (optional)" [ngModel]="orderNo()" (ngModelChange)="orderNo.set($event)">
          </div>
          <textarea class="border border-warmborder rounded-[9px] px-3.5 py-2.5 text-[13.8px] bg-paper outline-none focus:border-flame focus:bg-white min-h-[110px] resize-y"
            placeholder="How can we help?" [ngModel]="message()" (ngModelChange)="message.set($event)"></textarea>
          @if (submitted() && !valid()) {
            <p class="text-danger text-[12.5px]">Please provide your name, a valid email, and a message.</p>
          }
          <button class="btn btn-flame self-start" (click)="submit()">Send Message</button>
        </div>
      }
    </div>
  `,
})
export class ContactComponent {
  name = signal('');
  email = signal('');
  orderNo = signal('');
  message = signal('');
  sent = signal(false);
  submitted = signal(false);

  valid = computed(() =>
    this.name().trim() !== '' && this.email().includes('@') && this.message().trim() !== '',
  );

  submit(): void {
    this.submitted.set(true);
    if (!this.valid()) return;
    // API mode: POST /api/v1/store/contact
    this.sent.set(true);
  }
}
