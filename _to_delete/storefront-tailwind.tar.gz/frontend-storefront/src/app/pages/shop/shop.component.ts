import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService, DataService } from '../../services/data.service';
import { Category, Product, finalPrice } from '../../models';

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating';

const SUBS_BY_CATEGORY: Record<string, string[]> = {
  textiles: ['Bedding & Linen', 'Rugs & Throws'],
  decor: ['Lighting', 'Wall Art', 'Vases & Planters'],
  furniture: ['Seating', 'Tables'],
};

@Component({
  selector: 'sf-shop',
  imports: [RouterLink, FormsModule],
  template: `
    <div class="max-w-[1180px] mx-auto px-7 py-8 pb-16">
      <div class="text-[12.5px] text-warmmuted mb-2">Home / <b class="text-warmink">Shop</b></div>
      <h1 class="font-display text-[28px] font-bold mb-5">Shop All</h1>

      <div class="grid grid-cols-1 md:grid-cols-[230px_1fr] gap-8 items-start">
        <aside>
          <h4 class="text-[12.5px] uppercase tracking-wide text-warmmuted font-semibold mb-3">Category</h4>
          <label class="flex items-center gap-2 mb-2.5 text-[13.5px] cursor-pointer">
            <input type="radio" name="cat" class="w-4 h-4 accent-flame" [checked]="!categoryFilter()" (change)="categoryFilter.set('')"> All
          </label>
          @for (c of categories(); track c.id) {
            <label class="flex items-center gap-2 mb-2.5 text-[13.5px] cursor-pointer">
              <input type="radio" name="cat" class="w-4 h-4 accent-flame" [checked]="categoryFilter() === c.id" (change)="categoryFilter.set(c.id)"> {{ c.name }}
            </label>
          }

          <h4 class="text-[12.5px] uppercase tracking-wide text-warmmuted font-semibold mt-6 mb-3">Price</h4>
          @for (b of priceBands; track b.value) {
            <label class="flex items-center gap-2 mb-2.5 text-[13.5px] cursor-pointer">
              <input type="radio" name="price" class="w-4 h-4 accent-flame" [checked]="priceBand() === b.value" (change)="priceBand.set(b.value)"> {{ b.label }}
            </label>
          }

          <h4 class="text-[12.5px] uppercase tracking-wide text-warmmuted font-semibold mt-6 mb-3">Availability</h4>
          <label class="flex items-center gap-2 mb-2.5 text-[13.5px] cursor-pointer">
            <input type="checkbox" class="w-4 h-4 accent-flame" [checked]="inStockOnly()" (change)="inStockOnly.set(!inStockOnly())"> In stock only
          </label>

          <div class="text-[12.5px] text-flame font-semibold cursor-pointer mt-4" (click)="clearFilters()">Clear all filters</div>
        </aside>

        <div>
          <div class="flex justify-between items-center mb-4 text-[13px] text-warmmuted">
            <span>{{ filtered().length }} products</span>
            <select [ngModel]="sort()" (ngModelChange)="sort.set($event)"
              class="border border-warmborder rounded-[9px] px-3 py-2 text-[13px] bg-white outline-none">
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>

          <div class="grid grid-cols-2 xl:grid-cols-3 gap-4">
            @for (p of filtered(); track p.id) {
              <div class="border border-warmborder rounded-2xl overflow-hidden bg-white transition hover:shadow-xl hover:-translate-y-0.5">
                <div class="relative aspect-square flex items-center justify-center text-5xl bg-paper cursor-pointer" [routerLink]="['/product', p.id]">
                  {{ p.emoji }}
                  @if (p.discount) { <span class="absolute top-2.5 left-2.5 bg-flame text-white text-[10.5px] font-bold px-2 py-0.5 rounded-full">-{{ p.discount }}%</span> }
                  <button (click)="cart.toggleWish(p); $event.stopPropagation()"
                    class="absolute top-2 right-2 w-8 h-8 rounded-full bg-white shadow flex items-center justify-center text-sm cursor-pointer"
                    [class.text-flame]="cart.isWished(p)">♥</button>
                </div>
                <div class="p-4">
                  <div class="text-[11px] text-warmmuted uppercase tracking-wide mb-1">{{ p.sub }}</div>
                  <div class="text-sm font-semibold mb-1.5 cursor-pointer" [routerLink]="['/product', p.id]">{{ p.name }}</div>
                  <div class="text-[11.5px] text-warmmuted mb-2">★ {{ p.rating }}</div>
                  <div class="flex items-center justify-between">
                    <span class="font-display font-bold text-[15.5px]">\${{ finalPrice(p) }}
                      @if (p.discount) { <span class="text-xs text-warmmuted line-through font-medium ml-1.5">\${{ p.price }}</span> }
                    </span>
                    @if (p.stock > 0) {
                      <button (click)="cart.add(p)" class="w-8 h-8 rounded-[9px] bg-warmink hover:bg-warmink-2 text-white text-[15px] cursor-pointer">+</button>
                    }
                  </div>
                  @if (p.stock === 0) { <div class="text-[10.5px] font-bold text-danger mt-1.5">Out of stock</div> }
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ShopComponent implements OnInit {
  private data = inject(DataService);
  private route = inject(ActivatedRoute);
  cart = inject(CartService);

  products = signal<Product[]>([]);
  categories = signal<Category[]>([]);
  categoryFilter = signal('');
  priceBand = signal('');
  inStockOnly = signal(false);
  sort = signal<SortKey>('featured');

  finalPrice = finalPrice;

  priceBands = [
    { value: '', label: 'Any price' },
    { value: '0-50', label: 'Under $50' },
    { value: '50-150', label: '$50 – $150' },
    { value: '150-300', label: '$150 – $300' },
    { value: '300-9999', label: 'Over $300' },
  ];

  filtered = computed(() => {
    let list = this.products();

    const cat = this.categoryFilter();
    if (cat) list = list.filter(p => (SUBS_BY_CATEGORY[cat] ?? []).includes(p.sub));

    const band = this.priceBand();
    if (band) {
      const [min, max] = band.split('-').map(Number);
      list = list.filter(p => finalPrice(p) >= min && finalPrice(p) <= max);
    }

    if (this.inStockOnly()) list = list.filter(p => p.stock > 0);

    const sorted = [...list];
    switch (this.sort()) {
      case 'price-asc': sorted.sort((a, b) => finalPrice(a) - finalPrice(b)); break;
      case 'price-desc': sorted.sort((a, b) => finalPrice(b) - finalPrice(a)); break;
      case 'rating': sorted.sort((a, b) => b.rating - a.rating); break;
      default: sorted.sort((a, b) => Number(b.featured) - Number(a.featured));
    }
    return sorted;
  });

  clearFilters(): void {
    this.categoryFilter.set('');
    this.priceBand.set('');
    this.inStockOnly.set(false);
    this.sort.set('featured');
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(q => this.categoryFilter.set(q.get('category') ?? ''));
    this.data.getProducts().subscribe(p => this.products.set(p));
    this.data.getCategories().subscribe(c => this.categories.set(c));
  }
}
