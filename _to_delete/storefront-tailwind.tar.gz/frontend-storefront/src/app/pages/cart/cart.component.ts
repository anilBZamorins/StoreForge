import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CartService } from '../../services/data.service';
import { finalPrice } from '../../models';
import { MOCK_STORE } from '../../mock';

@Component({
  selector: 'sf-cart',
  imports: [RouterLink],
  template: `
    <div class="max-w-[1180px] mx-auto px-7 py-8 pb-16">
      <div class="text-[12.5px] text-warmmuted mb-2">Home / <b class="text-warmink">Cart</b></div>
      <h1 class="font-display text-[28px] font-bold mb-5">Your Cart</h1>

      @if (!cart.items().length) {
        <div class="text-center py-16">
          <div class="text-5xl mb-3.5">🛒</div>
          <h3 class="font-display text-lg font-bold mb-2">Your cart is empty</h3>
          <p class="text-warmmuted mb-5">Add something you love — it'll show up here.</p>
          <a routerLink="/shop" class="btn btn-dark">Browse the Shop</a>
        </div>
      } @else {
        <div class="grid grid-cols-1 md:grid-cols-[1.6fr_1fr] gap-8 items-start">
          <div>
            @if (remainingForFree > 0) {
              <div class="bg-paper border border-warmborder rounded-xl px-4 py-3 text-[13px] text-warmmuted mb-2">
                Add <b class="text-warmink">\${{ remainingForFree }}</b> more for free shipping
                <div class="h-1.5 bg-warmborder rounded-full mt-2 overflow-hidden">
                  <i class="block h-full bg-flame rounded-full" [style.width.%]="freeShipPct"></i>
                </div>
              </div>
            } @else {
              <div class="bg-paper border border-warmborder rounded-xl px-4 py-3 text-[13px] text-success font-semibold mb-2">✓ Your order qualifies for free shipping</div>
            }

            @for (i of cart.items(); track i.product.id) {
              <div class="flex gap-4 items-center py-4 border-b border-warmborder">
                <div class="w-[66px] h-[66px] rounded-xl bg-paper flex items-center justify-center text-[28px] cursor-pointer" [routerLink]="['/product', i.product.id]">{{ i.product.emoji }}</div>
                <div class="flex-1 flex flex-col gap-0.5 text-sm">
                  <b class="cursor-pointer" [routerLink]="['/product', i.product.id]">{{ i.product.name }}</b>
                  <span class="text-xs text-warmmuted">\${{ finalPrice(i.product) }} each</span>
                  <span class="text-xs text-danger cursor-pointer" (click)="cart.remove(i.product.id)">Remove</span>
                </div>
                <div class="inline-flex items-center border border-warmborder rounded-lg">
                  <button (click)="cart.setQty(i.product.id, i.qty - 1)" class="w-7 h-8 cursor-pointer">−</button>
                  <span class="w-7 text-center text-[13px] font-semibold">{{ i.qty }}</span>
                  <button (click)="cart.setQty(i.product.id, i.qty + 1)" class="w-7 h-8 cursor-pointer">+</button>
                </div>
                <div class="w-[70px] text-right font-bold text-sm">\${{ finalPrice(i.product) * i.qty }}</div>
              </div>
            }
          </div>

          <div class="border border-warmborder rounded-2xl p-6 bg-paper sticky top-24">
            <h3 class="font-display text-[15px] font-bold mb-3.5">Order Summary</h3>
            <div class="flex justify-between py-2 text-[13.8px]"><span>Subtotal</span><span>\${{ cart.subtotal() }}</span></div>
            <div class="flex justify-between py-2 text-[13.8px]"><span>Shipping</span><span>{{ cart.shipping() === 0 ? 'Free' : '$' + cart.shipping() }}</span></div>
            <div class="flex justify-between pt-3.5 mt-2.5 border-t border-warmborder font-bold text-base"><span>Total</span><span>\${{ cart.total() }}</span></div>
            <a routerLink="/checkout" class="btn btn-flame btn-block btn-lg mt-4">Proceed to Checkout</a>
            <a routerLink="/shop" class="btn btn-ghost btn-block mt-2.5">Continue Shopping</a>
          </div>
        </div>
      }
    </div>
  `,
})
export class CartComponent {
  cart = inject(CartService);
  finalPrice = finalPrice;
  freeShippingOver = MOCK_STORE.freeShippingOver;

  get remainingForFree(): number {
    return Math.max(0, this.freeShippingOver - this.cart.subtotal());
  }

  get freeShipPct(): number {
    return Math.min(100, Math.round((this.cart.subtotal() / this.freeShippingOver) * 100));
  }
}
