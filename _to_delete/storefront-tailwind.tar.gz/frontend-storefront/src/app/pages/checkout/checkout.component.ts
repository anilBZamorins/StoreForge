import { Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService, DataService } from '../../services/data.service';
import { finalPrice } from '../../models';

@Component({
  selector: 'sf-checkout',
  imports: [FormsModule, RouterLink],
  template: `
    <div class="max-w-[1180px] mx-auto px-7 py-8 pb-16">
      @if (!orderId()) {
        <div class="text-[12.5px] text-warmmuted mb-2">Home / Cart / <b class="text-warmink">Checkout</b></div>
        <h1 class="font-display text-[28px] font-bold mb-5">Checkout</h1>

        <div class="grid grid-cols-1 md:grid-cols-[1.4fr_1fr] gap-9 items-start">
          <div>
            <div class="border border-warmborder rounded-2xl p-6 mb-5 flex flex-col gap-3">
              <h3 class="font-display text-[15px] font-bold flex items-center gap-2 mb-1.5">
                <span class="w-6 h-6 rounded-full bg-warmink text-white text-xs inline-flex items-center justify-center">1</span> Delivery Details
              </h3>
              <input [class]="inputCls(invalid(name()))" [ngModel]="name()" (ngModelChange)="name.set($event)" placeholder="Full Name">
              <div class="grid grid-cols-2 gap-3">
                <input [class]="inputCls(false)" [ngModel]="email()" (ngModelChange)="email.set($event)" placeholder="Email">
                <input [class]="inputCls(invalid(phone()))" [ngModel]="phone()" (ngModelChange)="phone.set($event)" placeholder="Phone">
              </div>
              <input [class]="inputCls(invalid(address()))" [ngModel]="address()" (ngModelChange)="address.set($event)" placeholder="Address">
              <div class="grid grid-cols-3 gap-3">
                <input [class]="inputCls(invalid(city()))" [ngModel]="city()" (ngModelChange)="city.set($event)" placeholder="City">
                <input [class]="inputCls(false)" [ngModel]="state()" (ngModelChange)="state.set($event)" placeholder="State">
                <input [class]="inputCls(false)" [ngModel]="zip()" (ngModelChange)="zip.set($event)" placeholder="Zip Code">
              </div>
              @if (submitted() && !valid()) {
                <p class="text-danger text-[12.5px]">Please fill in name, phone, address and city.</p>
              }
            </div>

            <div class="border border-warmborder rounded-2xl p-6 flex flex-col gap-2.5">
              <h3 class="font-display text-[15px] font-bold flex items-center gap-2 mb-1.5">
                <span class="w-6 h-6 rounded-full bg-warmink text-white text-xs inline-flex items-center justify-center">2</span> Payment Method
              </h3>
              <label class="flex items-center gap-3 border border-flame bg-flame-dim rounded-[10px] p-3.5 cursor-pointer">
                <input type="radio" name="pay" checked class="w-4 h-4 accent-flame">
                <span class="flex flex-col gap-0.5">
                  <b class="text-[13.8px]">Cash on Delivery</b>
                  <small class="text-[11.5px] text-warmmuted font-normal">Pay in cash when your order is delivered</small>
                </span>
              </label>
              <label class="flex items-center gap-3 border border-warmborder rounded-[10px] p-3.5 opacity-55 cursor-not-allowed" title="Card payments arrive in Phase 2">
                <input type="radio" name="pay" disabled class="w-4 h-4">
                <span class="flex flex-col gap-0.5">
                  <b class="text-[13.8px]">Credit / Debit Card</b>
                  <small class="text-[11.5px] text-warmmuted font-normal">Coming soon — Visa, Mastercard, Amex</small>
                </span>
              </label>
            </div>
          </div>

          <div class="border border-warmborder rounded-2xl p-6 bg-paper sticky top-24">
            <h3 class="font-display text-[15px] font-bold mb-3.5">Order Summary</h3>
            @for (i of cart.items(); track i.product.id) {
              <div class="flex justify-between gap-3 py-1.5 text-[13.3px]">
                <span>{{ i.product.emoji }} {{ i.product.name }} × {{ i.qty }}</span>
                <span>\${{ finalPrice(i.product) * i.qty }}</span>
              </div>
            }
            <div class="flex justify-between py-1.5 text-[13.3px]"><span>Subtotal</span><span>\${{ cart.subtotal() }}</span></div>
            <div class="flex justify-between py-1.5 text-[13.3px]"><span>Shipping</span><span>{{ cart.shipping() === 0 ? 'Free' : '$' + cart.shipping() }}</span></div>
            <div class="flex justify-between pt-3.5 mt-2.5 border-t border-warmborder font-bold text-base"><span>Total</span><span>\${{ cart.total() }}</span></div>
            <button class="btn btn-flame btn-block btn-lg mt-4" (click)="placeOrder()" [disabled]="!cart.items().length || placing()">
              {{ placing() ? 'Placing order…' : 'Place Order' }}
            </button>
          </div>
        </div>
      } @else {
        <div class="max-w-[560px] mx-auto mt-10 text-center">
          <div class="w-[74px] h-[74px] rounded-full bg-sage-dim text-sage text-[32px] flex items-center justify-center mx-auto mb-5">✓</div>
          <h1 class="font-display text-[26px] font-bold mb-2.5">Order confirmed!</h1>
          <p class="text-warmmuted mb-6">Thanks for shopping with us. A confirmation email is on its way.</p>
          <div class="border border-warmborder rounded-[14px] p-5 text-left mb-6">
            <div class="flex justify-between py-2 border-b border-dashed border-warmborder text-[13.5px]"><span class="text-warmmuted">Order Number</span><b>{{ orderId() }}</b></div>
            <div class="flex justify-between py-2 border-b border-dashed border-warmborder text-[13.5px]"><span class="text-warmmuted">Payment Method</span><b>Cash on Delivery</b></div>
            <div class="flex justify-between py-2 text-[13.5px]"><span class="text-warmmuted">Estimated Delivery</span><b>5–8 business days</b></div>
          </div>
          <div class="flex gap-3 justify-center">
            <a routerLink="/" class="btn btn-ghost">Continue Shopping</a>
            <a routerLink="/track" class="btn btn-dark">Track Your Order</a>
          </div>
        </div>
      }
    </div>
  `,
})
export class CheckoutComponent {
  cart = inject(CartService);
  private data = inject(DataService);

  name = signal('');
  email = signal('');
  phone = signal('');
  address = signal('');
  city = signal('');
  state = signal('');
  zip = signal('');
  submitted = signal(false);
  placing = signal(false);
  orderId = signal<string | null>(null);

  finalPrice = finalPrice;

  valid = computed(() =>
    this.name().trim() !== '' && this.phone().trim() !== '' &&
    this.address().trim() !== '' && this.city().trim() !== '',
  );

  invalid(v: string): boolean {
    return this.submitted() && v.trim() === '';
  }

  inputCls(err: boolean): string {
    return 'border rounded-lg px-3 py-2.5 text-[13.5px] bg-paper outline-none focus:border-flame focus:bg-white ' +
      (err ? 'border-danger' : 'border-warmborder');
  }

  placeOrder(): void {
    this.submitted.set(true);
    if (!this.valid() || !this.cart.items().length || this.placing()) return;
    this.placing.set(true);
    this.data.placeOrder({
      name: this.name(), email: this.email(), phone: this.phone(),
      address: this.address(), city: this.city(), state: this.state(), zip: this.zip(),
      items: this.cart.items().map(i => ({ productId: i.product.id, qty: i.qty })),
      paymentMethod: 'COD',
      total: this.cart.total(),
    }).subscribe(r => {
      this.orderId.set(r.orderId);
      this.cart.clear();
      this.placing.set(false);
    });
  }
}
