import { Component, OnInit, computed, effect, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CartService, DataService } from '../../services/data.service';
import { Product, finalPrice } from '../../models';

@Component({
  selector: 'sf-product',
  imports: [RouterLink],
  template: `
    @if (product(); as p) {
      <div class="max-w-[1180px] mx-auto px-7 py-8 pb-16">
        <div class="text-[12.5px] text-warmmuted mb-3.5">Home / Shop / <b class="text-warmink">{{ p.name }}</b></div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div class="aspect-square rounded-[18px] bg-paper flex items-center justify-center text-[110px]">{{ p.emoji }}</div>
          <div>
            <div class="text-xs text-warmmuted uppercase tracking-wide mb-2">{{ p.sub }}</div>
            <h1 class="font-display text-[28px] font-bold mb-2">{{ p.name }}</h1>
            <div class="text-[13px] text-warmmuted mb-4">★ {{ p.rating }} · {{ p.stock > 0 ? p.stock + ' in stock' : 'Out of stock' }}</div>
            <div class="font-display font-extrabold text-[26px] mb-3.5">
              \${{ finalPrice(p) }}
              @if (p.discount) {
                <span class="text-[15px] text-warmmuted line-through font-medium ml-2">\${{ p.price }}</span>
                <span class="bg-flame-dim text-flame text-[11.5px] font-bold px-2.5 py-0.5 rounded-full ml-2 align-middle">Save {{ p.discount }}%</span>
              }
            </div>
            <p class="text-warmmuted text-sm leading-relaxed mb-5">{{ p.desc }}</p>

            <div class="inline-flex items-center border border-warmborder rounded-[9px]">
              <button (click)="qty.set(qty() > 1 ? qty() - 1 : 1)" class="w-[38px] h-[42px] text-base cursor-pointer">−</button>
              <span class="w-10 text-center font-semibold">{{ qty() }}</span>
              <button (click)="qty.set(qty() + 1)" class="w-[38px] h-[42px] text-base cursor-pointer">+</button>
            </div>

            <div class="flex gap-3 mt-5">
              <button class="btn btn-dark btn-lg" [disabled]="p.stock === 0" (click)="addToCart()">
                {{ added() ? '✓ Added to Cart' : 'Add to Cart' }}
              </button>
              <button class="btn btn-ghost btn-lg" (click)="cart.toggleWish(p)">{{ cart.isWished(p) ? '♥ Wishlisted' : '♡ Wishlist' }}</button>
            </div>

            <div class="flex gap-5 mt-6 pt-5 border-t border-warmborder text-[12.5px] text-warmmuted flex-wrap">
              <span>🚚 Free shipping over $99</span><span>💵 Cash on Delivery</span><span>↩ 14-day returns</span>
            </div>
          </div>
        </div>

        <div class="flex gap-6 border-b border-warmborder mt-11">
          <button (click)="tab.set('desc')" class="pb-3 text-sm font-semibold cursor-pointer border-b-2"
            [class]="tab() === 'desc' ? 'text-warmink border-flame' : 'text-warmmuted border-transparent'">Description</button>
          <button (click)="tab.set('ship')" class="pb-3 text-sm font-semibold cursor-pointer border-b-2"
            [class]="tab() === 'ship' ? 'text-warmink border-flame' : 'text-warmmuted border-transparent'">Shipping &amp; Returns</button>
        </div>
        <p class="text-warmmuted text-sm leading-[1.75] max-w-[720px] my-5">
          {{ tab() === 'desc' ? p.desc : shippingCopy }}
        </p>

        @if (related().length) {
          <h2 class="font-display text-2xl font-bold mt-11 mb-4">You may also like</h2>
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            @for (r of related(); track r.id) {
              <div class="border border-warmborder rounded-2xl overflow-hidden bg-white">
                <div class="aspect-square flex items-center justify-center text-5xl bg-paper cursor-pointer" [routerLink]="['/product', r.id]">{{ r.emoji }}</div>
                <div class="p-4">
                  <div class="text-sm font-semibold mb-2 cursor-pointer" [routerLink]="['/product', r.id]">{{ r.name }}</div>
                  <div class="flex items-center justify-between">
                    <span class="font-display font-bold text-[15.5px]">\${{ finalPrice(r) }}</span>
                    <button (click)="cart.add(r)" class="w-8 h-8 rounded-[9px] bg-warmink hover:bg-warmink-2 text-white text-[15px] cursor-pointer">+</button>
                  </div>
                </div>
              </div>
            }
          </div>
        }
      </div>
    } @else {
      <div class="max-w-[1180px] mx-auto px-7 py-8">
        <p class="text-warmmuted">Product not found. <a routerLink="/shop" class="text-flame font-semibold">Back to shop</a></p>
      </div>
    }
  `,
})
export class ProductComponent implements OnInit {
  id = input.required<string>();

  private data = inject(DataService);
  cart = inject(CartService);

  product = signal<Product | undefined>(undefined);
  all = signal<Product[]>([]);
  qty = signal(1);
  tab = signal<'desc' | 'ship'>('desc');
  added = signal(false);

  finalPrice = finalPrice;

  shippingCopy =
    "Orders are delivered via standard courier within 5–8 business days. Cash on Delivery is available on every order. " +
    "If something isn't right, you can return it unused within 14 days of delivery for a full refund.";

  related = computed(() => {
    const p = this.product();
    return p ? this.all().filter(x => x.sub === p.sub && x.id !== p.id).slice(0, 4) : [];
  });

  constructor() {
    effect(() => this.load(Number(this.id())));
  }

  private load(id: number): void {
    this.qty.set(1);
    this.tab.set('desc');
    this.added.set(false);
    this.data.getProduct(id).subscribe(p => this.product.set(p));
  }

  addToCart(): void {
    const p = this.product();
    if (!p || p.stock === 0) return;
    this.cart.add(p, this.qty());
    this.added.set(true);
    setTimeout(() => this.added.set(false), 2000);
  }

  ngOnInit(): void {
    this.data.getProducts().subscribe(ps => this.all.set(ps));
  }
}
