import { Component, OnDestroy, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CartService, DataService } from '../../services/data.service';
import { Category, Product, Slide, finalPrice } from '../../models';

@Component({
  selector: 'sf-home',
  imports: [RouterLink],
  template: `
    <div class="max-w-[1180px] mx-auto px-7 pt-6 pb-16">

      @if (slides().length) {
        <div class="relative rounded-[20px] p-14 min-h-[260px] text-white overflow-hidden mb-10" [style.background]="heroBg()">
          <div class="max-w-[440px]">
            <div class="text-xs font-bold tracking-[0.08em] uppercase opacity-85 mb-3">{{ slides()[idx()].eyebrow }}</div>
            <h1 class="font-display text-[38px] leading-[1.15] font-bold mb-3.5">{{ slides()[idx()].title }}</h1>
            <p class="text-[15px] opacity-90 mb-6 leading-relaxed">{{ slides()[idx()].sub }}</p>
            <a routerLink="/shop" class="btn btn-flame btn-lg">Shop Now</a>
          </div>
          <button (click)="prev()" class="absolute left-4 top-1/2 -translate-y-1/2 w-[38px] h-[38px] rounded-full bg-white/20 hover:bg-white/30 text-white text-lg cursor-pointer">‹</button>
          <button (click)="next()" class="absolute right-4 top-1/2 -translate-y-1/2 w-[38px] h-[38px] rounded-full bg-white/20 hover:bg-white/30 text-white text-lg cursor-pointer">›</button>
          <div class="absolute bottom-5 left-14 flex gap-[7px]">
            @for (s of slides(); track $index) {
              <button (click)="go($index)"
                class="h-2 rounded-full cursor-pointer transition-all"
                [class]="$index === idx() ? 'w-[22px] bg-white' : 'w-2 bg-white/40'"></button>
            }
          </div>
        </div>
      }

      <h2 class="font-display text-2xl font-bold mt-8 mb-4">Shop by category</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        @for (c of categories(); track c.id) {
          <a routerLink="/shop" [queryParams]="{ category: c.id }"
             class="rounded-2xl pt-14 pb-6 px-6 text-white font-display font-bold text-[19px]"
             [style.background]="'linear-gradient(135deg,' + c.color1 + ',' + c.color2 + ')'">{{ c.name }}</a>
        }
      </div>

      <h2 class="font-display text-2xl font-bold mt-8 mb-4">Featured products</h2>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        @for (p of featured(); track p.id) {
          <div class="border border-warmborder rounded-2xl overflow-hidden bg-white transition hover:shadow-xl hover:-translate-y-0.5">
            <div class="relative aspect-square flex items-center justify-center text-5xl bg-paper cursor-pointer" [routerLink]="['/product', p.id]">
              {{ p.emoji }}
              @if (p.discount) { <span class="absolute top-2.5 left-2.5 bg-flame text-white text-[10.5px] font-bold px-2 py-0.5 rounded-full">-{{ p.discount }}%</span> }
              <button (click)="cart.toggleWish(p); $event.stopPropagation()"
                class="absolute top-2 right-2 w-8 h-8 rounded-full bg-white shadow flex items-center justify-center text-sm cursor-pointer"
                [class.text-flame]="cart.isWished(p)">♥</button>
            </div>
            <div class="p-4">
              <div class="text-[11px] text-warmmuted uppercase tracking-wide mb-1">{{ p.sub }}</div>
              <div class="text-sm font-semibold mb-1.5 cursor-pointer" [routerLink]="['/product', p.id]">{{ p.name }}</div>
              <div class="text-[11.5px] text-warmmuted mb-2">★ {{ p.rating }}</div>
              <div class="flex items-center justify-between">
                <span class="font-display font-bold text-[15.5px]">\${{ finalPrice(p) }}
                  @if (p.discount) { <span class="text-xs text-warmmuted line-through font-medium ml-1.5">\${{ p.price }}</span> }
                </span>
                <button (click)="cart.add(p)" class="w-8 h-8 rounded-[9px] bg-warmink hover:bg-warmink-2 text-white text-[15px] cursor-pointer">+</button>
              </div>
            </div>
          </div>
        }
      </div>

      <h2 class="font-display text-2xl font-bold mt-8 mb-4">New arrivals</h2>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        @for (p of latest(); track p.id) {
          <div class="border border-warmborder rounded-2xl overflow-hidden bg-white transition hover:shadow-xl hover:-translate-y-0.5">
            <div class="aspect-square flex items-center justify-center text-5xl bg-paper cursor-pointer" [routerLink]="['/product', p.id]">{{ p.emoji }}</div>
            <div class="p-4">
              <div class="text-[11px] text-warmmuted uppercase tracking-wide mb-1">{{ p.sub }}</div>
              <div class="text-sm font-semibold mb-1.5 cursor-pointer" [routerLink]="['/product', p.id]">{{ p.name }}</div>
              <div class="flex items-center justify-between">
                <span class="font-display font-bold text-[15.5px]">\${{ finalPrice(p) }}</span>
                <button (click)="cart.add(p)" class="w-8 h-8 rounded-[9px] bg-warmink hover:bg-warmink-2 text-white text-[15px] cursor-pointer">+</button>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class HomeComponent implements OnInit, OnDestroy {
  private data = inject(DataService);
  cart = inject(CartService);

  slides = signal<Slide[]>([]);
  categories = signal<Category[]>([]);
  featured = signal<Product[]>([]);
  latest = signal<Product[]>([]);
  idx = signal(0);
  private timer: ReturnType<typeof setInterval> | undefined;

  finalPrice = finalPrice;

  heroBg = computed(() => {
    const s = this.slides()[this.idx()];
    return s
      ? `radial-gradient(ellipse at top right, rgba(255,90,54,0.18) 0%, transparent 55%), linear-gradient(135deg, ${s.c1}, ${s.c2})`
      : '';
  });

  next(): void { this.go(this.idx() + 1); }
  prev(): void { this.go(this.idx() - 1); }

  go(i: number): void {
    const n = this.slides().length;
    if (n) this.idx.set(((i % n) + n) % n);
    this.restartAutoplay();
  }

  private restartAutoplay(): void {
    clearInterval(this.timer);
    this.timer = setInterval(() => {
      const n = this.slides().length;
      if (n) this.idx.set((this.idx() + 1) % n);
    }, 6000);
  }

  ngOnInit(): void {
    this.data.getSlides().subscribe(s => { this.slides.set(s); this.restartAutoplay(); });
    this.data.getCategories().subscribe(c => this.categories.set(c));
    this.data.getProducts().subscribe(ps => {
      this.featured.set(ps.filter(p => p.featured));
      this.latest.set(ps.filter(p => p.latest));
    });
  }

  ngOnDestroy(): void {
    clearInterval(this.timer);
  }
}
