import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CartService } from '../../services/data.service';
import { Product, finalPrice } from '../../models';

@Component({
  selector: 'sf-wishlist',
  imports: [RouterLink],
  template: `
    <div class="max-w-[1180px] mx-auto px-7 py-8 pb-16">
      <div class="text-[12.5px] text-warmmuted mb-2">Home / <b class="text-warmink">Wishlist</b></div>
      <h1 class="font-display text-[28px] font-bold mb-4">Your Wishlist</h1>
      @if (!cart.wishlist().length) {
        <div class="text-center py-16">
          <div class="text-5xl mb-3.5">🤍</div>
          <h3 class="font-display text-lg font-bold mb-2">Your wishlist is empty</h3>
          <p class="text-warmmuted mb-5">Save pieces you love and come back to them anytime.</p>
          <a routerLink="/shop" class="btn btn-dark">Browse the Shop</a>
        </div>
      } @else {
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          @for (p of cart.wishlist(); track p.id) {
            <div class="border border-warmborder rounded-2xl overflow-hidden bg-white">
              <div class="relative aspect-square flex items-center justify-center text-5xl bg-paper cursor-pointer" [routerLink]="['/product', p.id]">
                {{ p.emoji }}
                <button (click)="cart.toggleWish(p); $event.stopPropagation()" title="Remove from wishlist"
                  class="absolute top-2 right-2 w-8 h-8 rounded-full bg-white shadow flex items-center justify-center text-sm text-flame cursor-pointer">♥</button>
              </div>
              <div class="p-4">
                <div class="text-[11px] text-warmmuted uppercase tracking-wide mb-1">{{ p.sub }}</div>
                <div class="text-sm font-semibold mb-2 cursor-pointer" [routerLink]="['/product', p.id]">{{ p.name }}</div>
                <div class="font-display font-bold text-[15.5px] mb-2.5">\${{ finalPrice(p) }}</div>
                <button (click)="moveToCart(p)" class="btn btn-ghost btn-block !text-[12.5px] !px-3 !py-2">Move to Cart</button>
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class WishlistComponent {
  cart = inject(CartService);
  finalPrice = finalPrice;

  moveToCart(p: Product): void {
    this.cart.add(p);
    this.cart.toggleWish(p);
  }
}
