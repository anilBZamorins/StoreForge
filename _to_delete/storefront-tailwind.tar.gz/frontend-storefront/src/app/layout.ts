import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { CartService, DataService } from './services/data.service';

@Component({
  selector: 'sf-store-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="bg-gradient-to-r from-warmink to-warmink-2 text-white text-center text-[12.5px] py-2">
      Free shipping on orders over <b class="text-flame-pale">\${{ data.store.freeShippingOver }}</b> · Cash on Delivery available at checkout
    </div>

    <div class="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-warmborder">
      <div class="max-w-[1180px] mx-auto px-7 h-[72px] flex items-center gap-5">
        <a routerLink="/" class="flex items-center gap-2.5 font-display font-extrabold text-[19px]">
          <span class="w-[34px] h-[34px] rounded-[10px] bg-gradient-to-br from-flame to-[#ff8a5c] inline-flex items-center justify-center text-white text-[15px]">{{ data.store.name.charAt(0) }}</span>
          {{ data.store.name }}
        </a>
        <nav class="flex gap-1">
          <a routerLink="/" routerLinkActive="!text-warmink font-bold" [routerLinkActiveOptions]="{ exact: true }"
             class="px-3.5 py-2 rounded-lg text-[13.8px] text-warmmuted hover:bg-paper">Home</a>
          <a routerLink="/shop" routerLinkActive="!text-warmink font-bold" class="px-3.5 py-2 rounded-lg text-[13.8px] text-warmmuted hover:bg-paper">Shop</a>
          <a routerLink="/track" routerLinkActive="!text-warmink font-bold" class="px-3.5 py-2 rounded-lg text-[13.8px] text-warmmuted hover:bg-paper">Track Order</a>
          <a routerLink="/contact" routerLinkActive="!text-warmink font-bold" class="px-3.5 py-2 rounded-lg text-[13.8px] text-warmmuted hover:bg-paper">Contact</a>
        </nav>
        <div class="ml-auto flex gap-2 text-base">
          <a routerLink="/wishlist" title="Wishlist" class="px-3 py-2 rounded-[10px] inline-flex items-center gap-1.5 hover:bg-paper">
            ♡ @if (cart.wishlist().length) { <span class="bg-flame text-white text-[10.5px] font-bold min-w-[17px] h-[17px] rounded-full inline-flex items-center justify-center px-1">{{ cart.wishlist().length }}</span> }
          </a>
          <a routerLink="/cart" title="Cart" class="px-3 py-2 rounded-[10px] inline-flex items-center gap-1.5 hover:bg-paper">
            🛒 @if (cart.count()) { <span class="bg-flame text-white text-[10.5px] font-bold min-w-[17px] h-[17px] rounded-full inline-flex items-center justify-center px-1">{{ cart.count() }}</span> }
          </a>
        </div>
      </div>
    </div>

    <router-outlet />

    <footer class="bg-paper border-t border-warmborder py-6 text-[13px] text-warmmuted mt-16">
      <div class="max-w-[1180px] mx-auto px-7 flex justify-between flex-wrap gap-2.5">
        <span>© 2026 {{ data.store.name }}.</span>
        <span>Powered by <b>StoreForge</b></span>
      </div>
    </footer>
  `,
})
export class Layout {
  data = inject(DataService);
  cart = inject(CartService);
}
